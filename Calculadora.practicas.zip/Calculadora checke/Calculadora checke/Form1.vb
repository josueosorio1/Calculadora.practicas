﻿Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim Suma, Resta, Multi, Division, Raiz, eleva As Boolean
        If Me.Suma.Checked = True Then
            Suma = True
        Else
            Suma = False
        End If
        If Me.Resta.Checked = True Then
            Resta = True
        Else
            Resta = False
        End If
        If Me.Multi.Checked = True Then
            Multi = True
        Else
            Multi = False
        End If
        If Me.Division.Checked = True Then
            Division = True
        Else
            Division = False
        End If
        If Me.Raiz.Checked = True Then
            Raiz = True
        Else
            Raiz = False
        End If
        If Me.eleva.Checked = True Then
            eleva = True
        Else
            eleva = False
        End If
        Dim a, b As Integer
        Dim r As Double
        If Me.Suma.Checked = True Then
            Suma = True
            a = txt1.Text
            b = txt2.Text
            r = a + b
            MsgBox("la suma es: " + r.ToString)
        Else
            Suma = False
        End If
        If Me.Resta.Checked = True Then
            Resta = True
            a = txt1.Text
            b = txt2.Text
            r = a - b
            MsgBox("la resta es: " + r.ToString)
        Else
            Resta = False
        End If
        If Me.Multi.Checked = True Then
            Multi = True
            a = txt1.Text
            b = txt2.Text
            r = a * b
            MsgBox("la multiplicacion es: " + r.ToString)
        Else
            Multi = False
        End If
        If Me.Division.Checked = True Then
            Division = True
            a = txt1.Text
            b = txt2.Text
            r = a / b
            MsgBox("la division es: " + r.ToString)
        Else
            Division = False

        End If
        If Me.Raiz.Checked = True Then
            Raiz = True
            a = txt1.Text
            r = Math.Sqrt(a)
            MsgBox("la raiz es: " + r.ToString)
        Else
            Raiz = False
        End If
        If Me.eleva.Checked = True Then
            eleva = True
            a = txt1.Text
            b = txt2.Text
            r = a ^ b
            MsgBox("la elevacion que ingresaste es: " + r.ToString)
        Else
            eleva = False
        End If
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        txt1.Text = ""
        txt2.Text = ""
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
